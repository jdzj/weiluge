# [zxdic.com](http://zxdic.com)
在线字典,汉字笔画

## 这有啥用？
就是为了方便给我的孩子看清汉字笔画，学习拼音。

## 来源声明
1.忘记在哪下载来的了，不知道作者是谁，在此感谢！我有作了简单的修改，适配了手机。

2.汉字笔画原作者为：[林木木](https://immmmm.com/)，原始数据来自 [Make Me a Hanzi](https://github.com/skishore/makemeahanzi) 项目.。
